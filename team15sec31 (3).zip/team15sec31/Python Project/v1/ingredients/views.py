from django.shortcuts import render, get_object_or_404
from .models import Ingredient  # Assuming you have an Ingredient model

# Create your views here.

def ingredient_list(request):
    ingredients = Ingredient.objects.all()
    return render(request, 'ingredients/ingredient_list.html', {'ingredients': ingredients})

def ingredient_detail(request, id):
    ingredient = get_object_or_404(Ingredient, id=id)
    return render(request, 'ingredients/ingredient_detail.html', {'ingredient': ingredient})
