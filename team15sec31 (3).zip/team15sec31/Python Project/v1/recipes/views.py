from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.forms import AuthenticationForm
from .models import Recipe, Player, Sport
from .forms import RecipeForm
from django.http import JsonResponse
from django.contrib import messages

def home(request):
    if request.user.is_authenticated:
        recipes = Recipe.objects.all()
        login_form = None
    else:
        recipes = []
        login_form = AuthenticationForm()
    return render(request, 'recipes/home.html', {'recipes': recipes, 'login_form': login_form})

def add_recipe(request):
    if request.method == 'POST':
        form = RecipeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = RecipeForm()
    return render(request, 'recipes/add_recipe.html', {'form': form})

def add_player(request):
    if request.method == 'POST':
        name = request.POST['name']
        sport_id = request.POST['sport']
        matches_played = request.POST.get('matches_played', 0)
        wins = request.POST.get('wins', 0)
        losses = request.POST.get('losses', 0)

        # Validate data
        if not name or not sport_id:
            messages.error(request, "Name and Sport are required.")
            return redirect('players_view')

        try:
            matches_played = int(matches_played)
            wins = int(wins)
            losses = int(losses)
        except ValueError:
            messages.error(request, "Matches played, wins, and losses must be numbers.")
            return redirect('players_view')

        # Create a new player object
        player = Player.objects.create(
            name=name,
            sport_id=sport_id,
            matches_played=matches_played,
            wins=wins,
            losses=losses
        )

        messages.success(request, "Player added successfully!")
        return redirect('players_view')
    
    # Handle GET request - Note the template path change here
    sports = Sport.objects.all()
    return render(request, 'recipes/add_player.html', {'sports': sports})

def edit_recipe(request, id):
    recipe = get_object_or_404(Recipe, id=id)
    if request.method == 'POST':
        # Don't update title, description, and location even if they're in POST data
        post_data = request.POST.copy()
        post_data['title'] = recipe.title
        post_data['description'] = recipe.description
        post_data['location'] = recipe.location
        
        form = RecipeForm(post_data, instance=recipe)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = RecipeForm(instance=recipe)
        # Make fields read-only
        form.fields['title'].widget.attrs['readonly'] = True
        form.fields['description'].widget.attrs['readonly'] = True
        form.fields['location'].widget.attrs['readonly'] = True
    
    return render(request, 'recipes/edit_recipe.html', {'form': form, 'recipe': recipe})

def delete_recipe(request, id):
    recipe = get_object_or_404(Recipe, id=id)
    if request.method == 'POST':
        recipe.delete()
        return redirect('home')
    return render(request, 'recipes/delete_recipe.html', {'recipe': recipe})

def recipe_detail(request, id):
    recipe = get_object_or_404(Recipe, id=id)
    if request.method == 'POST':
        team1_score = request.POST.get('team1_score')
        team2_score = request.POST.get('team2_score')
        recipe.team1_score = int(team1_score)
        recipe.team2_score = int(team2_score)
        recipe.save()

        # Determine the winner
        if recipe.team1_score > recipe.team2_score:
            winner = recipe.team1_name
        elif recipe.team2_score > recipe.team1_score:
            winner = recipe.team2_name
        else:
            winner = "Draw"

        return render(request, 'recipes/recipe_detail.html', {'recipe': recipe, 'winner': winner})
    return render(request, 'recipes/recipe_detail.html', {'recipe': recipe})

def update_score(request):
    if request.method == 'POST':
        event_id = request.POST.get('event')
        home_score = request.POST.get('homeScore')
        away_score = request.POST.get('awayScore')

        if not event_id or not home_score or not away_score:
            # Handle missing data
            return redirect('home')

        recipe = get_object_or_404(Recipe, id=event_id)
        recipe.team1_score = int(home_score)
        recipe.team2_score = int(away_score)
        recipe.save()

        # Determine the winner
        if recipe.team1_score > recipe.team2_score:
            winner = recipe.team1_name
        elif recipe.team2_score > recipe.team1_score:
            winner = recipe.team2_name
        else:
            winner = "Draw"

        # Redirect to the recipe_detail page with the winner information
        return redirect('recipe_detail', id=recipe.id)

    return redirect('home')

def chess_detail(request, id):
    recipe = get_object_or_404(Recipe, id=id)  # Get the specific recipe instance
    
    # Initialize scores if they don't exist
    if recipe.team1_score is None:
        recipe.team1_score = 0
    if recipe.team2_score is None:
        recipe.team2_score = 0

    # Handle score update if POST request
    if request.method == 'POST':
        home_score = request.POST.get('homeScore', 0)
        away_score = request.POST.get('awayScore', 0)
        recipe.team1_score = int(home_score)
        recipe.team2_score = int(away_score)
        recipe.save()
        return redirect('chess_detail', id=id)  # Redirect to the same page

    return render(request, 'recipes/chess_detail.html', {'recipe': recipe})  # Pass the recipe instance

def players_view(request):
    players = Player.objects.all()
    sports = Sport.objects.all()
    return render(request, 'recipes/players01.html', {
        'players': players,
        'sports': sports
    })

def add_player(request):
    if request.method == 'POST':
        name = request.POST['name']
        sport_id = request.POST['sport']
        matches_played = request.POST.get('matches_played', 0)
        wins = request.POST.get('wins', 0)
        losses = request.POST.get('losses', 0)

        # Validate data
        if not name or not sport_id:
            messages.error(request, "Name and Sport are required.")
            return redirect('players_view')

        try:
            matches_played = int(matches_played)
            wins = int(wins)
            losses = int(losses)
        except ValueError:
            messages.error(request, "Matches played, wins, and losses must be numbers.")
            return redirect('players_view')

        # Create a new player object
        player = Player.objects.create(
            name=name,
            sport_id=sport_id,
            matches_played=matches_played,
            wins=wins,
            losses=losses
        )

        messages.success(request, "Player added successfully!")
        return redirect('players_view')
    
    # Handle GET request
    sports = Sport.objects.all()
    return render(request, 'recipes/add_player.html', {'sports': sports})

def add_player(request):
    if request.method == 'POST':
        name = request.POST['name']
        age = request.POST['age']
        sport_id = request.POST['sport']
        tournaments_played = request.POST['tournaments_played']
        rank = request.POST['rank']

        # Validate data
        if not name or not sport_id or not age:
            messages.error(request, "Name, Age, and Sport are required.")
            return redirect('add_player')  # Redirect back to the add player page

        # Create a new player object
        player = Player.objects.create(
            name=name,
            age=age,
            sport_id=sport_id,
            tournaments_played=tournaments_played,
            rank=rank
        )

        messages.success(request, "Player added successfully!")  # Success message
        return redirect('players')  # Redirect to the players list view
    else:
        sports = Sport.objects.all()  # Get all sports for the dropdown
        return render(request, 'add_player.html', {'sports': sports})  # Render the add player form