from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import google.generativeai as genai
import json
import logging

logger = logging.getLogger(__name__)

# Configure the Gemini API key
GEMINI_API_KEY = "AIzaSyC12JvB6SL_lCfNPmi0QlveiUUPLqbl7eA"  # Replace with your actual API key
genai.configure(api_key=GEMINI_API_KEY)

@csrf_exempt
def chatbot(request):
    if request.method == 'POST':
        try:
            # Parse the incoming request
            data = json.loads(request.body)
            message = data.get('message', '')
            
            if not message:
                return JsonResponse({'error': 'Message is required'}, status=400)

            # Initialize the model
            model = genai.GenerativeModel('gemini-pro')
            
            # Generate the response
            response = model.generate_content(message)
            
            # Check if response generation was successful
            if response and hasattr(response, 'text'):
                return JsonResponse({
                    'response': response.text,
                    'status': 'success'
                })
            else:
                logger.error("Empty or invalid response from Gemini")
                return JsonResponse({
                    'error': 'Failed to generate response',
                    'status': 'error'
                }, status=500)
                
        except json.JSONDecodeError as e:
            logger.error(f"JSON Decode Error: {str(e)}")
            return JsonResponse({
                'error': 'Invalid JSON format',
                'status': 'error'
            }, status=400)
            
        except Exception as e:
            logger.error(f"Chatbot Error: {str(e)}", exc_info=True)
            return JsonResponse({
                'error': 'Internal server error',
                'status': 'error'
            }, status=500)
    
    return JsonResponse({
        'error': 'Method not allowed',
        'status': 'error'
    }, status=405)